<?php

	$av_config = array();
	
	$av_config['key'] = 'کلید تایید اعتبار کاربر در تنظیمات افزونه را اینجا وارد کنید.';
	
	$av_config['free_dl_speed'] = 100; // حداکثر سرعت دانلود رایگان
	
	$av_config['site_url'] = 'http://127.0.0.1/rtl/'; // آدرس سایت شما که کاربران در آن ثبت نام کرده اند.
	 
	$av_config['files_folder'] = 'files'; // نام پوشه ای که فایل های خود را در آن قرار داد اید
	
	$av_config['files_path'] = dirname(__FILE__) . '/' . $av_config['files_folder'] . '/'; // این خط را ویرایش نکنید!
	