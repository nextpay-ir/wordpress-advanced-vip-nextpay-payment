<?php
	if( ! defined('ABSPATH') ) die();
	function av_dashbourd_func(){ ?>
	<div class="wrap av-dashboard">
	
		<div class="av-dashboard-box">
			<p>افزونه حرفه ای عضویت ویژه</p>
			<p>طراحی  و برنامه نویسی <a href="http://vahidd.com">وحید محمدی</a></p>
			<p>قدرت گرفته توسط <a href="https://nextpay.ir">درگاه پرداخت نکست پی</a></p>
			<p>برای ارسال پیشنهادات و گزارش باگ می توانید به آدرس <code>vahid-mohamadi@live.com</code> ایمیل بزنید.</p>
		</div>
		
	</div>
	<?php } 
