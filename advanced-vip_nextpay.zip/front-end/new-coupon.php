<?php
if( ! defined('ABSPATH') ) die();
function av_add_coupon_func(){
global $av_settings,$avEcrypt,$wpdb,$avdb;

?>
	<div class="wrap av-new-vip-coupons">
		<h2 style="font-family:yekan,tahoma;font-weight:normal;font-size:19px;">اضافه کردن کوپن جدید</h2>
		<div class="clr"></div>
	</div>



<?php } 