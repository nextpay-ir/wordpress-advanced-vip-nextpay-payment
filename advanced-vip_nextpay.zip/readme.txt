=== Iranian VIP ===
Contributors: vahidd 
Donate link:http://vahidd.com
Tags: Iranian VIP, Advanced VIP
Requires at least: 3.5
Tested up to: 3.5
Stable tag: trunk

Iranian VIP is a powerful plugin that only can be used in iran.

== Description ==

With this plugin you can create vip accounts for your wordpress site. this plugin also included a nice online payment (faragate) for charge accounts.

== Installation ==

Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.

==Readme Generator== 

This Readme file was generated using <a href = 'http://sudarmuthu.com/wordpress/wp-readme'>wp-readme</a>, which generates readme files for WordPress Plugins.